package ex01.setsuper;

import java.io.File;
import java.io.IOException;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import target.Rectangle;

public class SetSuperclass {
   static final String SEP = File.separator;
   static String workDir = System.getProperty("user.dir");
   static String outputDir = workDir + SEP + "output";

   public static void main(String[] args) {
	   if (args.length != 3) {
		   System.out.println("Invalid number of arguments. Please restart program with 3 elements");
		   System.exit(0);
	   }
	   else {
		   for (int i = 0; i < args.length; i++) {
			   int num = i + 1;
			   System.out.println("Argument " + num + ": " + args[i]);
		   }
	   }
	   System.out.println("");
	   
      try {
         ClassPool pool = ClassPool.getDefault();

         boolean useRuntimeClass = true;
         if (useRuntimeClass) {
            insertClassPathRunTimeClass(pool);
         } else {
            insertClassPath(pool);
         }
         
         if (args[0].length() > 5 && args[0].substring(0,6).equals("Common") && args[1].length() > 5 &&  args[1].substring(0,6).equals("Common") && args[2].length() > 5 && args[2].substring(0,6).equals("Common")) {
        	 if (args[0].length() > args[1].length() && args[0].length() > args[2].length()) {
				 CtClass cc = pool.get("target." + args[1]);
				 setSuperclass(cc, "target." + args[0], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[0], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
			 }
			 else if (args[1].length() > args[0].length()) {
				 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[1], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[1], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
			 }
			 else {
				 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[2], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[1]);
				 setSuperclass(cc2, "target." + args[2], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
			 }
         }
         else if (args[0].length() > 5 && args[0].substring(0,6).equals("Common") && args[1].length() > 5 && args[1].substring(0,6).equals("Common")) {
        	 if (args[0].length() > args[1].length()) {
        		 CtClass cc = pool.get("target." + args[1]);
				 setSuperclass(cc, "target." + args[0], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[0], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
        	 else {
        		 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[1], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[1], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
         }
         else if (args[0].length() > 5 && args[0].substring(0,6).equals("Common") && args[2].length() > 5 && args[2].substring(0,6).equals("Common")) {
        	 if (args[0].length() > args[2].length()) {
        		 CtClass cc = pool.get("target." + args[1]);
				 setSuperclass(cc, "target." + args[0], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[0], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
        	 else {
        		 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[2], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[1]);
				 setSuperclass(cc2, "target." + args[2], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
         }
         else if (args[1].length() > 5 && args[1].substring(0,6).equals("Common") && args[2].length() > 5 && args[2].substring(0,6).equals("Common")) {
        	 if (args[1].length() > args[2].length()) {
        		 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[1], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[2]);
				 setSuperclass(cc2, "target." + args[1], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
        	 else {
        		 CtClass cc = pool.get("target." + args[0]);
				 setSuperclass(cc, "target." + args[2], pool);
				 cc.writeFile(outputDir);
				 cc.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
				 
				 CtClass cc2 = pool.get("target." + args[1]);
				 setSuperclass(cc2, "target." + args[2], pool);
				 cc2.writeFile(outputDir);
				 cc2.defrost();
				 System.out.println("[DBG] write output to: " + outputDir);
        	 }
         }
         else if (args[0].length() > 5 && args[0].substring(0,6).equals("Common")) {
        	 CtClass cc = pool.get("target." + args[1]);
			 setSuperclass(cc, "target." + args[0], pool);
			 cc.writeFile(outputDir);
			 cc.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
			 
			 CtClass cc2 = pool.get("target." + args[2]);
			 setSuperclass(cc2, "target." + args[0], pool);
			 cc2.writeFile(outputDir);
			 cc2.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
         }
         else if (args[1].length() > 5 && args[1].substring(0,6).equals("Common")) {
        	 CtClass cc = pool.get("target." + args[0]);
			 setSuperclass(cc, "target." + args[1], pool);
			 cc.writeFile(outputDir);
			 cc.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
			 
			 CtClass cc2 = pool.get("target." + args[2]);
			 setSuperclass(cc2, "target." + args[1], pool);
			 cc2.writeFile(outputDir);
			 cc2.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
         }
         else if (args[2].length() > 5 && args[2].substring(0,6).equals("Common")) {
        	 CtClass cc = pool.get("target." + args[0]);
			 setSuperclass(cc, "target." + args[2], pool);
			 cc.writeFile(outputDir);
			 cc.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
			 
			 CtClass cc2 = pool.get("target." + args[1]);
			 setSuperclass(cc2, "target." + args[2], pool);
			 cc2.writeFile(outputDir);
			 cc2.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
         }
         else {
        	 CtClass cc = pool.get("target." + args[1]);
			 setSuperclass(cc, "target." + args[0], pool);
			 cc.writeFile(outputDir);
			 cc.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
			 
			 CtClass cc2 = pool.get("target." + args[2]);
			 setSuperclass(cc2, "target." + args[0], pool);
			 cc2.writeFile(outputDir);
			 cc2.defrost();
			 System.out.println("[DBG] write output to: " + outputDir);
         }
      } catch (NotFoundException | CannotCompileException | IOException e) {
         e.printStackTrace();
      }
   }

   static void insertClassPathRunTimeClass(ClassPool pool) throws NotFoundException {
      ClassClassPath classPath = new ClassClassPath(new Rectangle().getClass());
      pool.insertClassPath(classPath);
      //System.out.println("[DBG] insert classpath: " + classPath.toString());
   }

   static void insertClassPath(ClassPool pool) throws NotFoundException {
      String strClassPath = workDir + SEP + "bin"; // eclipse compile dir
      // String strClassPath = workDir + SEP + "classfiles"; // separate dir
      pool.insertClassPath(strClassPath);
      System.out.println("[DBG] insert classpath: " + strClassPath);
   }

   static void setSuperclass(CtClass curClass, String superClass, ClassPool pool) throws NotFoundException, CannotCompileException {
      curClass.setSuperclass(pool.get(superClass));
      System.out.println("[DBG] set superclass: " + curClass.getSuperclass().getName() + //
            ", subclass: " + curClass.getName());
   }
}
